package ${pkg}.repository

import ${pkg}.common.DataState
import ${pkg}.dao.HelloDao
import ${pkg}.dto.HelloDto
import ${pkg}.network.HelloService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class HelloRepository(
    private val dao: HelloDao,
    private val service: HelloService,
) {

    fun loadMore(key: String): Flow<DataState<List<HelloDto>>> = flow {
        try {
            emit(DataState.loading())
            var data = service.list(key = key, count = 20)
            emit(DataState.success(data = data))
        } catch (e: Exception) {
            emit(DataState.error<List<HelloDto>>(e.message ?: "Unknown Error"))
        }
    }

}