package ${pkg}.theme

import ${pkg}.R
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily

var roboto_regular_font = Font(R.font.roboto_regular)
var roboto_regular_font_family = FontFamily(roboto_regular_font)

var fasthand_regular_font = Font(R.font.fasthand_regular)
var fasthand_regular_font_family = FontFamily(fasthand_regular_font)

var hanuman_regular_font = Font(R.font.hanuman_regular)
var hanuman_regular_font_family = FontFamily(hanuman_regular_font)

var battambang_regular_font = Font(R.font.battambang_regular)
var battambang_regular_font_family = FontFamily(battambang_regular_font)

var chenla_regular_font = Font(R.font.chenla_regular)
var chenla_regular_font_family = FontFamily(chenla_regular_font)

var koulen_regular_font = Font(R.font.koulen_regular)
var koulen_regular_font_family = FontFamily(koulen_regular_font)

var moul_regular_font = Font(R.font.moul_regular)
var moul_regular_font_family = FontFamily(moul_regular_font)

var angkor_regular_font = Font(R.font.angkor_regular)
var angkor_regular_font_family = FontFamily(angkor_regular_font)

var khmer_regular_font = Font(R.font.khmer_regular)
var khmer_regular_font_family = FontFamily(khmer_regular_font)

var suwannaphum_regular_font = Font(R.font.suwannaphum_regular)
var suwannaphum_regular_font_family = FontFamily(suwannaphum_regular_font)

var metal_regular_font = Font(R.font.metal_regular)
var metal_regular_font_family = FontFamily(metal_regular_font)

var content_regular_font = Font(R.font.content_regular)
var content_regular_font_family = FontFamily(content_regular_font)

var bayon_regular_font = Font(R.font.bayon_regular)
var bayon_regular_font_family = FontFamily(bayon_regular_font)

var siemreap_regular_font = Font(R.font.siemreap_regular)
var siemreap_regular_font_family = FontFamily(siemreap_regular_font)

var kantumruy_regular_font = Font(R.font.kantumruy_regular)
var kantumruy_regular_font_family = FontFamily(kantumruy_regular_font)

var odormeanchey_regular_font = Font(R.font.odormeanchey_regular)
var odormeanchey_regular_font_family = FontFamily(odormeanchey_regular_font)

var dangrek_regular_font = Font(R.font.dangrek_regular)
var dangrek_regular_font_family = FontFamily(dangrek_regular_font)

var bokor_regular_font = Font(R.font.bokor_regular)
var bokor_regular_font_family = FontFamily(bokor_regular_font)

var taprom_regular_font = Font(R.font.taprom_regular)
var taprom_regular_font_family = FontFamily(taprom_regular_font)

var moulpali_regular_font = Font(R.font.moulpali_regular)
var moulpali_regular_font_family = FontFamily(moulpali_regular_font)

var preahvihear_regular_font = Font(R.font.preahvihear_regular)
var preahvihear_regular_font_family = FontFamily(preahvihear_regular_font)

var kdamthmor_regular_font = Font(R.font.kdamthmor_regular)
var kdamthmor_regular_font_family = FontFamily(kdamthmor_regular_font)

var notosanskhmerui_regular_font = Font(R.font.notosanskhmerui_regular)
var notosanskhmerui_regular_font_family = FontFamily(notosanskhmerui_regular_font)

var notosanskhmer_regular_font = Font(R.font.notosanskhmer_regular)
var notosanskhmer_regular_font_family = FontFamily(notosanskhmer_regular_font)
