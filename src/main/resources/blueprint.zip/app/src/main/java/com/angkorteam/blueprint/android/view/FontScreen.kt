package ${pkg}.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.Card
import androidx.compose.material.ContentAlpha
import androidx.compose.material.LocalContentAlpha
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import ${pkg}.theme.gray200
import ${pkg}.theme.fasthand_regular_font_family
import ${pkg}.theme.hanuman_regular_font_family
import ${pkg}.theme.battambang_regular_font_family
import ${pkg}.theme.chenla_regular_font_family
import ${pkg}.theme.koulen_regular_font_family
import ${pkg}.theme.moul_regular_font_family
import ${pkg}.theme.angkor_regular_font_family
import ${pkg}.theme.khmer_regular_font_family
import ${pkg}.theme.suwannaphum_regular_font_family
import ${pkg}.theme.metal_regular_font_family
import ${pkg}.theme.content_regular_font_family
import ${pkg}.theme.bayon_regular_font_family
import ${pkg}.theme.siemreap_regular_font_family
import ${pkg}.theme.kantumruy_regular_font_family
import ${pkg}.theme.odormeanchey_regular_font_family
import ${pkg}.theme.dangrek_regular_font_family
import ${pkg}.theme.bokor_regular_font_family
import ${pkg}.theme.taprom_regular_font_family
import ${pkg}.theme.moulpali_regular_font_family
import ${pkg}.theme.preahvihear_regular_font_family
import ${pkg}.theme.kdamthmor_regular_font_family
import ${pkg}.theme.notosanskhmer_regular_font_family
import ${pkg}.theme.notosanskhmerui_regular_font_family

@Composable
fun FontScreen() {

    var fonts = mapOf(
        "Fast Hand" to fasthand_regular_font_family,
        "Hanuman" to hanuman_regular_font_family,
        "Battambang" to battambang_regular_font_family,
        "Chenla" to chenla_regular_font_family,
        "Koulen" to koulen_regular_font_family,
        "Moul" to moul_regular_font_family,
        "Angkor" to angkor_regular_font_family,
        "Khmer" to khmer_regular_font_family,
        "Suwannaphum" to suwannaphum_regular_font_family,
        "Metal" to metal_regular_font_family,
        "Content" to content_regular_font_family,
        "Bayon" to bayon_regular_font_family,
        "Siem Reap" to siemreap_regular_font_family,
        "Kantumruy" to kantumruy_regular_font_family,
        "Odor Mean Chey" to odormeanchey_regular_font_family,
        "Dangrek" to dangrek_regular_font_family,
        "Bokor" to bokor_regular_font_family,
        "Taprom" to taprom_regular_font_family,
        "Moulpali" to moulpali_regular_font_family,
        "Preah Vihear" to preahvihear_regular_font_family,
        "Kdam Thmor" to kdamthmor_regular_font_family,
        "Noto Sans Khmer" to notosanskhmer_regular_font_family,
        "Noto Sans Khmer UI" to notosanskhmerui_regular_font_family,
    )

    Surface(
        modifier = Modifier.padding(0.dp)
    ) {
        LazyColumn {
            itemsIndexed(items = fonts.keys.toList()) { index, name ->
                if (index == 0) {
                    FontCard(
                        first = true,
                        last = false,
                        name = name,
                        description = "ខ្ញុំបានមើលព្យុះ ដែលមានភាពស្រស់ស្អាតណាស់ ប៉ុន្តែគួរឲ្យខ្លាច!",
                        font = fonts[name]
                    )
                } else if (index == fonts.size - 1) {
                    FontCard(
                        first = false,
                        last = true,
                        name = name,
                        description = "ខ្ញុំបានមើលព្យុះ ដែលមានភាពស្រស់ស្អាតណាស់ ប៉ុន្តែគួរឲ្យខ្លាច!",
                        font = fonts[name]
                    )
                } else {
                    FontCard(
                        first = false,
                        last = false,
                        name = name,
                        description = "ខ្ញុំបានមើលព្យុះ ដែលមានភាពស្រស់ស្អាតណាស់ ប៉ុន្តែគួរឲ្យខ្លាច!",
                        font = fonts[name]
                    )
                }
            }
        }
    }
}

@Composable
fun FontCard(
    first: Boolean,
    last: Boolean,
    name: String,
    description: String,
    font: FontFamily?
) {
    Card(
        modifier = Modifier
            .padding(
                top = if (first) 16.dp else 8.dp,
                bottom = if (last) 16.dp else 8.dp,
                start = 16.dp,
                end = 16.dp
            )
            .fillMaxWidth(),
        backgroundColor = MaterialTheme.colors.gray200,
        elevation = 4.dp,
    ) {

        var author = if (name == "Kantumruy" || name == "Kdam Thmor") "Tep Sovichet" else "Danh Hong"

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.h6
                )
                CompositionLocalProvider(LocalContentAlpha provides ContentAlpha.medium) {
                    Text(
                        text = "by $author",
                        style = MaterialTheme.typography.overline
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.body1,
                fontFamily = font
            )
        }
    }
}