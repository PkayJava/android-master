package ${pkg}.view

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.Card
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.material.rememberScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import ${pkg}.common.TAG
import ${pkg}.theme.BlueprintMasterTheme
import kotlinx.coroutines.ExperimentalCoroutinesApi

@ExperimentalComposeUiApi
@ExperimentalCoroutinesApi
@ExperimentalMaterialApi
@Composable
fun ListScreen(
    controller: NavHostController,
    model: ListScreenModel,
) {
    Log.d(TAG, "HelloListScreen: $model")

    val hellos = model.hellos.value

    val loading = model.loading.value

    val scaffoldState = rememberScaffoldState()

    BlueprintMasterTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text(text = "Puppy Quick App") })
            },
            scaffoldState = scaffoldState,
            snackbarHost = {
                scaffoldState.snackbarHostState
            },
        ) {
            Box(modifier = Modifier.background(color = MaterialTheme.colors.surface)) {
                if (loading && hellos.isEmpty()) {
                    Text(text = "Loading")
                } else if (hellos.isEmpty()) {
                    Text(text = "Nothing")
                } else {
                    LazyColumn {
                        itemsIndexed(items = hellos) { index, hello ->

                            model.state.set(STATE_KEY_LIST_POSITION, index)

                            Log.i(TAG, "index $index puppies size ${hellos.size}")
                            if (index + 1 == hellos.size) {
                                if (!loading) {
                                    model.loadMore()
                                }
                            }
                            Card(
                                modifier = Modifier
                                    .padding(10.dp)
                                    .height(50.dp)
                                    .fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .fillMaxSize()
                                ) {
                                    Text(text = hello.name)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
