package ${pkg}.common

const val TAG = "${app_name} Debug"
